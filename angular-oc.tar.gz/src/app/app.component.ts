import { Component, OnInit } from '@angular/core';
import { AppareilService } from './services/appareil.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'angular-oc';
  isAuth = false;
  appareils: any[] | undefined;
  

  currentTime = new Promise((resolve, reject) => {
    const date = new Date();
    setTimeout(
      () => {
        resolve(date);
      }, 1000
    );
  });

  constructor(private AppareilService : AppareilService) { 
    setTimeout(
      () => {
        this.isAuth = true;
      }, 4000
    );
  }

  ngOnInit() {
    this.appareils = this.AppareilService.appareils;
  }

  /*
  appareilOne = "Machine à laver";
  appareilTwo = "Frigo";
  appareilThree = "Lave vaiselle";
  */

  onAllumer() {
    this.AppareilService.switchOnAll();
  }

  onEteindre() {
    this.AppareilService.switchOffAll();
  }
}
