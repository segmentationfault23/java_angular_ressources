import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AppareilService {

    private appareils = [
        {
            id: 1,
            name: "Machine à laver",
            status: "ON"
        },
        {
            id: 2,
            name: "Frigo",
            status: "ON"
        },
        {
            id: 3,
            name: "Lave vaiselle",
            status: "ON"
        }
    ];

    switchOnAll() {
        for(let appareil of this.appareils) {
            appareil.status = "ON";
        }
    }

    switchOffAll() {
        for(let appareil of this.appareils) {
            appareil.status = "OFF";
        }
    }

    switchOnOne(index: number) {
        this.appareils[index].status = "ON";
    }

    switchOffOne(index: number) {
        this.appareils[index].status = "OFF";
    }

    constructor(private httpClient: HttpClient) {

    }
}